# Site LC Transporte

Site estático (HTML + CSS + JavaScript), sem dependências. Para ver, abra `index.html` no navegador.

## Estrutura
- `index.html` — todas as páginas (Início, Serviços, Integrações, Operações, Frota, Trabalhe conosco, Seja parceiro, Rastreio, Regras, Central de Ajuda, Sobre, Contato, Privacidade, Admin)
- `css/style.css` — visual (cores nas variáveis do começo: `--navy`, `--amber`...)
- `js/config.js` — **dados da empresa**: WhatsApp, telefone, e-mail, endereço, horário, redes sociais, lista de patrocinadores
- `js/main.js` — navegação, validação e envio dos formulários, FAQ, integrações e faixa de patrocinadores
- `assets/img/` — logo e fotos de fundo
- `assets/patrocinadores/` — logos dos patrocinadores

## Publicar
Envie a pasta inteira para qualquer hospedagem de site estático (Netlify, Vercel, GitHub Pages, hospedagem comum), com HTTPS.

## Antes de usar com dados reais
- Os formulários hoje abrem WhatsApp/e-mail com os dados preenchidos. Para receber e guardar dados, crie um back-end seguro e informe o endereço em `endpoint` (`js/config.js`).
- O painel Admin é só uma tela de exemplo, sem login real.
- Confirme o direito de uso das fotos, da logo (personagem) e dos logos dos patrocinadores.
- Revise a política de privacidade com um advogado.
