// =====================================================
//  CONFIGURAÇÃO DA LC TRANSPORTE  (edite apenas este arquivo)
// =====================================================
const CONFIG={
  whatsapp:"557599130331",          // com 55 + DDD + número, só dígitos
  telefone:"(75) 9913-0331",
  email:"roberto.fonseca@gmail.com",
  endereco:"",                      // ex.: "Rua X, 123 - Cidade/UF"
  horario:"",                       // ex.: "Seg a Sex, 8h às 18h"
  redes:"",                         // ex.: links de Instagram, Facebook...
  endpoint:"",                      // endereço do servidor que receberá os formulários (back-end)
  patrocinadores:[                  // logos em assets/patrocinadores/ (só com autorização das marcas)
    {nome:"Morango Brasil",logo:"assets/patrocinadores/01-morango-brasil.png"},
    {nome:"Nati",logo:"assets/patrocinadores/02-nati.png"},
    {nome:"Ocean Drop",logo:"assets/patrocinadores/03-ocean-drop.png"},
    {nome:"Onset",logo:"assets/patrocinadores/04-onset.png"},
    {nome:"Ouse",logo:"assets/patrocinadores/05-ouse.png"},
    {nome:"Pandora",logo:"assets/patrocinadores/06-pandora.png"},
    {nome:"Pantys",logo:"assets/patrocinadores/07-pantys.png"},
    {nome:"Puravida",logo:"assets/patrocinadores/08-puravida.png"},
    {nome:"SA Elétrica Industrial",logo:"assets/patrocinadores/09-sa-eletrica-industrial.png"},
    {nome:"Sephora",logo:"assets/patrocinadores/10-sephora.png"},
    {nome:"Tag",logo:"assets/patrocinadores/11-tag.png"},
    {nome:"The Casa",logo:"assets/patrocinadores/12-the-casa.png"},
    {nome:"Tok&Stok",logo:"assets/patrocinadores/13-tok-stok.png"},
    {nome:"Torra",logo:"assets/patrocinadores/14-torra.png"},
    {nome:"Vivara",logo:"assets/patrocinadores/15-vivara.png"},
    {nome:"Zyra",logo:"assets/patrocinadores/16-zyra.png"},
    {nome:"Patrocinador (logo estrela azul)",logo:"assets/patrocinadores/17-patrocinador-logo-estrela-azul.png"},
    {nome:"Dermapelle",logo:"assets/patrocinadores/18-dermapelle.png"},
    {nome:"Deus Ex Machina",logo:"assets/patrocinadores/19-deus-ex-machina.png"},
    {nome:"Jhelp",logo:"assets/patrocinadores/20-jhelp.png"},
    {nome:"Hope",logo:"assets/patrocinadores/21-hope.png"},
    {nome:"Ideia Laser",logo:"assets/patrocinadores/22-ideia-laser.png"},
    {nome:"Insider",logo:"assets/patrocinadores/23-insider.png"}
  ]
};
